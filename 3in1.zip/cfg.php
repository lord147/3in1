<?php

$useragent = "Mozilla/5.0 (Linux; Android 9; TECNO CC7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.101 Mobile Safari/537.36";



// 1 
$c_1xbitcoins = "bitmedia_fid=eyJmaWQiOiIwNjY5ZTZmOGIyYzk2YjZlMDczNjI5ZmEyZTVlYWI1MiIsImZpZG5vdWEiOiI5MGI1MzFjMzBhZjczZDM4ODBjMmU3NDNhZTQzNThkNCJ9; csrf_cookie_name=72e9074c5d7f1e9ebd68737df2e95e7d; ci_session=0497f40ba90020122dd6a6cb39cdd236b764d014";


// 2
$c_speedcoins = "ci_session=15b95f137591bf11e25460854ff0d24e9158870a; __cf_bm=_ZtUEgA5vWklQ0W49GpTjwyUB3o9J683NO.7V3o23Lk-1633271154-0-AZ2QLUcPAtyGkkWC/m5By0iHpOm+JS8EI4TVOUDQyG4fEO0H5ODriRJiXuhgbxhBjCywiMq6NNPl7oKZ/3j5/w+eSK1vIMgq8pkgMba4xUanr8vQlCmTS+AvGo6oxGHvog==; csrf_cookie_name=ce86311436b7cb3c0cba6861b0ebd64d";



// 3

$c_cryptoaf = "bitmedia_fid=eyJmaWQiOiIwNjY5ZTZmOGIyYzk2YjZlMDczNjI5ZmEyZTVlYWI1MiIsImZpZG5vdWEiOiI5MGI1MzFjMzBhZjczZDM4ODBjMmU3NDNhZTQzNThkNCJ9; _ga=GA1.2.1643334485.1633205302; _gid=GA1.2.1225591309.1633205302; csrf_cookie_name=b66f4958d38082d7d2f005d0a14802a6; ci_session=02f66eab29fb7376e71a3bf46047fc8a70a5d560";





